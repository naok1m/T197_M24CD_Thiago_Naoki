import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  Image,
  ActivityIndicator,
  StyleSheet
} from 'react-native';
import { Ionicons, FontAwesome } from '@expo/vector-icons';
import { useAuth } from './AuthContext';
import { db } from './firebaseConfig';
import styles from './styles';

export default function TelaNotificacoes({ navigation }) {
  const { currentUser, userData, loadingAuth } = useAuth();
  const [notificacoes, setNotificacoes] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!loadingAuth && currentUser) {
      carregarNotificacoes();
    }
  }, [currentUser, loadingAuth]);

  const carregarNotificacoes = async () => {
    try {
      const notificacoesRef = db.collection('notificacoes')
        .where('userId', '==', currentUser.uid)
        .orderBy('timestamp', 'desc');

      const snapshot = await notificacoesRef.get();
      const notificacoesList = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));

      setNotificacoes(notificacoesList);
    } catch (error) {
      console.error('Erro ao carregar notificações:', error);
    } finally {
      setLoading(false);
    }
  };

  const getIconeNotificacao = (tipo) => {
    switch (tipo) {
      case 'aprovacao':
        return <Ionicons name="checkmark-circle-outline" size={24} color="#4CAF50" />;
      case 'rejeicao':
        return <Ionicons name="close-circle-outline" size={24} color="#F44336" />;
      case 'alerta':
        return <Ionicons name="alert-circle-outline" size={24} color="#FF9800" />;
      default:
        return <Ionicons name="notifications-outline" size={24} color="#007bff" />;
    }
  };

  if (loadingAuth || loading) {
    return (
      <View style={[styles.container2, { justifyContent: 'center', alignItems: 'center' }]}>
        <ActivityIndicator size="large" color="#007bff" />
        <Text style={{ marginTop: 10 }}>Carregando notificações...</Text>
      </View>
    );
  }

  if (!currentUser || !userData) {
    return (
      <View style={[styles.container2, { justifyContent: 'center', alignItems: 'center' }]}>
        <Text style={{ textAlign: 'center', padding: 20 }}>
          Sessão encerrada. Por favor, faça login novamente.
        </Text>
        <TouchableOpacity
          style={styles.btnRegistrar}
          onPress={() => navigation.replace('TelaLogin')}
        >
          <Text style={styles.textoBtn}>IR PARA LOGIN</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.container2}>
      <View style={styles.headermain}>
        <Image
          source={require('./assets/real-logo.png')}
          style={styles.avatar}
        />
        <View>
          <Text style={styles.ola}>Olá,</Text>
          <Text style={styles.nome}>{userData?.nomeUsuario || 'Usuário'}!</Text>
        </View>
      </View>

      <ScrollView style={styles.listaRegistros}>
        {notificacoes.length === 0 ? (
          <View style={[styles.semRegistrosContainer, { height: 200 }]}>
            <Ionicons name="notifications-off-outline" size={48} color="#ccc" />
            <Text style={styles.semRegistros}>Nenhuma notificação no momento.</Text>
          </View>
        ) : (
          notificacoes.map((notificacao) => (
            <View key={notificacao.id} style={styles.cardNotificacao}>
              <View style={styles.notificacaoIcone}>
                {getIconeNotificacao(notificacao.tipo)}
              </View>
              <View style={styles.notificacaoConteudo}>
                <Text style={styles.notificacaoTitulo}>{notificacao.titulo}</Text>
                <Text style={styles.notificacaoMensagem}>{notificacao.mensagem}</Text>
                <Text style={styles.notificacaoData}>
                  {notificacao.timestamp?.toDate?.().toLocaleDateString('pt-BR') || 'Data não disponível'}
                </Text>
              </View>
            </View>
          ))
        )}
      </ScrollView>

      {/* MENU INFERIOR */}
      <View style={styles.menuInferior}>
        <TouchableOpacity onPress={() => navigation.navigate('TelaRegPonto')}>
          <FontAwesome name="home" size={28} color="gray" />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('TelaHistorico')}>
          <Ionicons name="stats-chart-outline" size={28} color="gray" />
        </TouchableOpacity>
        <TouchableOpacity>
          <Ionicons name="notifications-outline" size={28} color="#007bff" />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('TelaConfig')}>
          <Ionicons name="settings-outline" size={28} color="gray" />
        </TouchableOpacity>
      </View>
    </View>
  );
} 