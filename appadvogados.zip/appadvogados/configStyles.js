// styles.js
import { StyleSheet } from 'react-native';

export default function getStyles(modoEscuro) {
  return StyleSheet.create({
    containerConfig: {
      flex: 1,
      backgroundColor: modoEscuro ? '#121212' : '#fff',
      padding: 20,
    },
    headerConfig: {
      fontSize: 24,
      fontWeight: 'bold',
      color: modoEscuro ? '#fff' : '#000',
      marginBottom: 20,
    },
    section: {
      marginBottom: 30,
    },
    sectionTitle: {
      fontSize: 18,
      fontWeight: '600',
      marginBottom: 10,
      color: modoEscuro ? '#ccc' : '#333',
    },
    option: {
      fontSize: 16,
      color: modoEscuro ? '#eee' : '#000',
      paddingVertical: 10,
    },
    switchRow: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      paddingVertical: 10,
    },
  });
}
