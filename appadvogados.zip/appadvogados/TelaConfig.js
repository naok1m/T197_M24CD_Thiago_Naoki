import React, { useState } from 'react';
import { View, Text, Switch, TouchableOpacity, SafeAreaView, Alert } from 'react-native';
import getStyles from './configStyles';
import { auth } from './firebaseConfig';

export default function ConfiguracoesScreen({ navigation }) {
  const [notificacoesAtivadas, setNotificacoesAtivadas] = useState(true);
  const [modoEscuro, setModoEscuro] = useState(false);

  const styles = getStyles(modoEscuro);

  const toggleNotificacoes = () => setNotificacoesAtivadas(prev => !prev);
  const toggleModoEscuro = () => setModoEscuro(prev => !prev);

  const handleLogout = async () => {
    try {
      await auth.signOut();
      navigation.replace('TelaLogin');
    } catch (error) {
      console.error('Erro ao fazer logout:', error);
      Alert.alert('Erro', 'Não foi possível fazer logout. Tente novamente.');
    }
  };

  return (
    <SafeAreaView style={styles.containerConfig}>
      <Text style={styles.headerConfig}>Configurações</Text>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Conta</Text>
        <TouchableOpacity onPress={() => navigation.navigate('TelaPerfil')}>
          <Text style={styles.option}>Ver perfil</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={handleLogout}>
          <Text style={styles.option}>Sair</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Preferências</Text>
        <View style={styles.switchRow}>
          <Text style={styles.option}>Notificações</Text>
          <Switch value={notificacoesAtivadas} onValueChange={toggleNotificacoes} />
        </View>
        <View style={styles.switchRow}>
          <Text style={styles.option}>Modo Escuro</Text>
          <Switch value={modoEscuro} onValueChange={toggleModoEscuro} />
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Idioma</Text>
        <TouchableOpacity>
          <Text style={styles.option}>Português (Brasil)</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.section}>
        <TouchableOpacity onPress={() => navigation.navigate('TelaRegPonto')}>
          <Text style={styles.option}>Voltar para a Home</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}
               
