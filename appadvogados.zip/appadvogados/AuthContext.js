import React, { createContext, useState, useEffect, useContext } from 'react';
import { onAuthStateChanged } from 'firebase/auth';
import { auth, db } from './firebaseConfig';

export const AuthContext = createContext();

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth deve ser usado dentro de um AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [currentUser, setCurrentUser] = useState(null);
  const [userData, setUserData] = useState(null);
  const [loadingAuth, setLoadingAuth] = useState(true);

  // Função para carregar dados do usuário
  const carregarDadosUsuario = async (uid) => {
    try {
      console.log("AuthContext: Tentando carregar dados do usuário, UID:", uid);
      
      // Usando a sintaxe do Firebase v8
      const userDoc = await db.collection('usuarios').doc(uid).get();
      
      if (userDoc.exists) {
        const userData = userDoc.data();
        console.log("AuthContext: Dados do usuário carregados com sucesso:", userData);
        setUserData({ uid, ...userData });
        return true;
      } else {
        console.warn("AuthContext: Documento do usuário não encontrado no Firestore");
        setUserData(null);
        return false;
      }
    } catch (error) {
      console.error("AuthContext: Erro ao carregar dados do usuário:", error);
      setUserData(null);
      return false;
    }
  };

  useEffect(() => {
    console.log("AuthContext: Iniciando monitoramento de autenticação");
    
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      console.log("AuthContext: Estado de autenticação alterado", user ? "Usuário logado" : "Usuário deslogado");
      
      if (user) {
        console.log("AuthContext: Usuário detectado, UID:", user.uid);
        setCurrentUser(user);
        
        // Tenta carregar os dados do usuário
        const dadosCarregados = await carregarDadosUsuario(user.uid);
        
        if (!dadosCarregados) {
          console.warn("AuthContext: Não foi possível carregar os dados do usuário");
          // Tenta novamente após um pequeno delay
          setTimeout(async () => {
            await carregarDadosUsuario(user.uid);
          }, 1000);
        }
      } else {
        console.log("AuthContext: Nenhum usuário autenticado");
        setCurrentUser(null);
        setUserData(null);
      }
      
      setLoadingAuth(false);
    });

    return () => {
      console.log("AuthContext: Limpando monitoramento de autenticação");
      unsubscribe();
    };
  }, []);

  const value = {
    currentUser,
    userData,
    loadingAuth,
    recarregarDadosUsuario: async () => {
      if (currentUser) {
        await carregarDadosUsuario(currentUser.uid);
      }
    }
  };

  console.log("AuthContext: Estado atual:", {
    currentUser: !!currentUser,
    userData: !!userData,
    loadingAuth
  });

  return (
    <AuthContext.Provider value={value}>
      {!loadingAuth && children}
    </AuthContext.Provider>
  );
};