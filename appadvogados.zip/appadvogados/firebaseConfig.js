import firebase from 'firebase';
import 'firebase/firestore';
import 'firebase/auth';

// Your Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCjUja7u8h6ZaURiof33IwcinCIV3iIcHY",
  authDomain: "appadvogados-ecdcf.firebaseapp.com",
  projectId: "appadvogados-ecdcf",
  storageBucket: "appadvogados-ecdcf.firebasestorage.app",
  messagingSenderId: "648791793241",
  appId: "1:648791793241:web:150f22e285afe593899b48",
  measurementId: "G-M919GE5D3Z"
};

let app;
let db;
let auth;

try {
  // Initialize Firebase (only if it hasn't been initialized yet)
  if (!firebase.apps.length) {
    app = firebase.initializeApp(firebaseConfig);
  } else {
    app = firebase.app();
  }

  // Get references to services
  db = firebase.firestore();
  auth = firebase.auth();

  // Configurações adicionais do Firestore
  db.settings({
    timestampsInSnapshots: true,
    merge: true
  });

  console.log('Firebase inicializado com sucesso');
} catch (error) {
  console.error('Erro ao inicializar Firebase:', error);
}

export { firebase, db, auth };