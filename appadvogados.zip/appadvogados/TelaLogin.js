import React, { useState } from 'react';
import { View, TextInput, Text, TouchableOpacity, ImageBackground, Modal, SafeAreaView, ActivityIndicator, Platform, Keyboard, TouchableWithoutFeedback } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialCommunityIcons } from 'react-native-vector-icons';
import { firebase, auth, db } from './firebaseConfig';
import styles from './styles';
import { useTheme } from './ThemeContext';
import { useAuth } from './AuthContext';

function TelaLogin({ navigation }) {
  const { currentUser, userData } = useAuth();
  const [text_email, setText_email] = useState('');
  const [text_senha, setText_senha] = useState('');
  const [senhaVisivel, setSenhaVisivel] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [modalMessage, setModalMessage] = useState('');
  const [modalType, setModalType] = useState('');

  // Se o usuário já estiver autenticado, redireciona para a tela de registro de ponto
  React.useEffect(() => {
    console.log('TelaLogin: Verificando autenticação', {
      currentUser: !!currentUser,
      userData: !!userData
    });

    if (currentUser && userData) {
      console.log('TelaLogin: Usuário já autenticado, redirecionando para TelaRegPonto');
      navigation.replace('TelaRegPonto');
    }
  }, [currentUser, userData]);

  const handleLogin = async () => {
    if (text_email === '' || text_senha === '') {
      setModalMessage('Preencha todos os campos!');
      setModalType('error');
      setModalVisible(true);
      return;
    }

    setIsLoading(true);
    console.log('TelaLogin: Iniciando processo de login');

    try {
      // Tenta fazer login com email e senha
      const userCredential = await auth.signInWithEmailAndPassword(text_email, text_senha);
      const user = userCredential.user;
      console.log('TelaLogin: Login bem sucedido, UID:', user.uid);

      // Verifica se o email foi verificado
      if (!user.emailVerified) {
        console.log('TelaLogin: Email não verificado');
        setModalMessage('Por favor, verifique seu email antes de fazer login.');
        setModalType('error');
        setModalVisible(true);
        return;
      }

      // Busca os dados adicionais do usuário no Firestore
      const userDoc = await db.collection('usuarios').doc(user.uid).get();
      
      if (userDoc.exists) {
        const userData = userDoc.data();
        console.log('TelaLogin: Dados do usuário carregados:', userData);
        
        // Registra o login no histórico
        await db.collection('logins').add({
          userId: user.uid,
          email: text_email,
          timestamp: firebase.firestore.FieldValue.serverTimestamp(),
          device: Platform.OS,
          nomeUsuario: userData.nomeUsuario
        });

        setModalMessage('Login realizado com sucesso!');
        setModalType('success');
        setModalVisible(true);

        // Limpa os campos
        setText_email('');
        setText_senha('');

        // Navega para a próxima tela
        console.log('TelaLogin: Redirecionando para TelaRegPonto');
        navigation.replace('TelaRegPonto');
      } else {
        console.error('TelaLogin: Dados do usuário não encontrados');
        throw new Error('Dados do usuário não encontrados');
      }

    } catch (error) {
      console.error('TelaLogin: Erro durante o login:', error);
      let mensagemErro = 'Erro ao fazer login';

      switch (error.code) {
        case 'auth/invalid-email':
          mensagemErro = 'Email inválido';
          break;
        case 'auth/user-disabled':
          mensagemErro = 'Usuário desativado';
          break;
        case 'auth/user-not-found':
          mensagemErro = 'Usuário não encontrado';
          break;
        case 'auth/wrong-password':
          mensagemErro = 'Senha incorreta';
          break;
        default:
          mensagemErro = 'Erro ao fazer login: ' + error.message;
      }

      setModalMessage(mensagemErro);
      setModalType('error');
      setModalVisible(true);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
      <SafeAreaView style={styles.containerLogin}>
        <LinearGradient
          colors={['rgb(255,255,255)', 'transparent']}
          style={styles.background2}
        />

        <View> 
          <ImageBackground 
            source={require('./assets/real-logo.png')} 
            style={styles.container_banner}
          />
        </View>

        <View style={styles.containerInput}>
          <Text style={styles.texto_login}>Mais um dia mais uma conquista!</Text>
        </View>

        <View>
          <TextInput
            style={styles.input_contato}
            placeholder="Email"
            placeholderTextColor='black'
            value={text_email}
            onChangeText={setText_email}
            keyboardType="email-address"
            autoCapitalize="none"
          />

          <View style={[styles.input_contato, { flexDirection: 'row', alignItems: 'center', paddingRight: 10 }]}>
            <TextInput
              style={{ flex: 1, color: 'black' }}
              placeholder="Senha"
              placeholderTextColor='black'
              value={text_senha}
              onChangeText={setText_senha}
              secureTextEntry={!senhaVisivel}
            />

            <TouchableOpacity onPress={() => setSenhaVisivel(!senhaVisivel)}>
              <MaterialCommunityIcons
                name={senhaVisivel ? 'eye' : 'eye-off'}
                size={17}
                color="black"
              />
            </TouchableOpacity>
          </View>

          <Text 
            onPress={() => navigation.navigate('RecupSenha')} 
            style={{ color: "black", textDecorationLine: "underline" }}
          >
            Esqueceu sua senha?
          </Text>

          <View style={styles.containerInput}>
            <TouchableOpacity 
              onPress={handleLogin}
              style={{
                backgroundColor: 'blue',
                width: 230,
                height: 40,
                alignItems: 'center',
                justifyContent: 'center',
                borderRadius: 20,
              }}
              disabled={isLoading}
            >
              {isLoading ? (
                <ActivityIndicator color="white" />
              ) : (
                <Text style={{ color: 'white', fontWeight: 'bold' }}>ENTRAR</Text>
              )}
            </TouchableOpacity>

            <TouchableOpacity 
              onPress={() => navigation.navigate('TelaCadastro')}
              style={{ marginTop: 15 }}
            >
              <Text style={{ color: 'black', textAlign: 'center' }}>
                Não tem uma conta? <Text style={{ color: 'blue', fontWeight: 'bold' }}>Cadastre-se</Text>
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Modal de alerta */}
        <Modal
          visible={modalVisible}
          animationType="fade"
          transparent={true}
          onRequestClose={() => setModalVisible(false)}
        >
          <View style={styles.modalContainer}>
            <View style={styles.modalContent}>
              <Text style={modalType === 'success' ? styles.modalSuccessText : styles.modalErrorText}>
                {modalMessage}
              </Text>

              <TouchableOpacity onPress={() => setModalVisible(false)} style={styles.modalButton}>
                <Text style={styles.modalButtonText}>Fechar</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
      </SafeAreaView>
    </TouchableWithoutFeedback>
  );
}

export default TelaLogin;
