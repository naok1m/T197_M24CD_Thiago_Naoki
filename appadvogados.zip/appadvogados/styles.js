import { StyleSheet } from 'react-native';
const styles = StyleSheet.create({


 container_principal:{
 flex:1,
 backgroundColor: 'beige',
 },
 container_infos:{
 flex: 2 ,
 justifyContent:'center',
 alignItems:'center',
 },
 texto_apresentacao:{
 color: '#897868',
 fontWeight:'bold',
 fontSize: 20,
 },
 texto:{
 color: '#897868',
 fontWeight:'bold',
 },
 imagem: {
   width: 800,
   height: 800,
   resizeMode: 'cover',
   borderRadius: 300,
   borderWidth: 3,
   borderColor: '#897868'
 },
container_icons:{
  flex: 1,
  flexDirection: 'row',
  justifyContent: 'center',
  alignItems: 'flex-start',
},
texto_instituicao: {
  color: 'white',
  textDecorationLine: 'underline',
},
background: {
  flex: 1,
  resizeMode: "cover",
  justifyContent: "center",
  backgroundColor: 'red',
},
botao:{
backgroundColor: '#897868',
 width: 150,
 height: 40,
 alignItems: 'center',
 justifyContent: 'center',
 borderRadius: 20,
},

texto_botao:{
 color:'white',
 fontSize: 15,
},
container_botao:{
  flex:0.3,
  alignItems: 'center',
  justifyContent: 'flex-start'
},

container_contato:{
flex: 2,
padding: 10,
backgroundColor: 'white',
borderWidth: 1,
borderColor: '#6A1B9A',
marginBottom: 15,
shadowColor: '#6A1B9A',
shadowOffset: { width: 0, height: 3 },
shadowOpacity: 0.2,
shadowRadius: 4,
elevation: 5,
},

container_icone_voltar_contato:{
alignItems:'flex-start',
},

view_texto_contato:{
alignItems: 'center',
padding: 10,
},

texto_contato:{
color:'black',
fontWeight: 'bold',
padding: 10,
fontSize: 25,
},

input_contato:{
height: 40,
borderColor: 'black',
borderWidth: 1.2,
marginBottom: 20,
paddingLeft: 10,
borderRadius: 12,
width: 300
},

input_contato_scrowlView:{
borderColor: 'grey',
borderWidth: 1,
marginBottom: 30,
paddingLeft: 10,
borderRadius: 20,
height: 120, textAlignVertical: 'top'
},

textarea: {
height: 50,
textAlignVertical: 'top',
marginBottom: 5,
},


containerLogin:{
backgroundColor: "white",
  flex: 1,
  padding: 0,
  alignItems: "center",
  justifyContent: "center", // já está OK aqui
},

texto_login:{
  fontFamily: 'Poppins',
  fontSize: 15,
  color: '#6a6a6a',
  textAlign: 'center',
  opacity: 1, // antes era 0.3
},

texto_login2:{
fontFamily: 'Poppins',
fontWeight:'bold',
fontSize: 30,
justifyContent: "center",
padding: 20,
},

containerInput: {
  flex: 0.3,
  padding: 30,
  alignItems: "center",
  justifyContent: "center"
},
container_banner:{
flex:0.1,
padding:10,
height: 200,
width: 200,
resizeMode: 'cover'
},

// Recuperação de Senha STYLES.JS:
container: {
    flex: 1,
    backgroundColor: "white",
  },
  header: {
    backgroundColor: "blue",
    padding: 20,
    alignItems: "center",
  },
  header2: {
    backgroundColor: "blue",
    padding: 30,
    alignItems: "center",
  },
  headerText: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 20,
  },
  content: {
    padding: 20,
    alignItems: "center",
  },
  iconRecu: {
    fontSize: 48,
    marginBottom: 20,
  },
  title: {
    fontWeight: "bold",
    fontSize: 16,
    marginBottom: 10,
  },
  subtitle: {
    textAlign: "center",
    color: "#555",
    marginBottom: 20,
  },
  input: {
    width: "100%",
    backgroundColor: "#fff",
    padding: 12,
    borderRadius: 8,
    marginBottom: 20,
  },
  button: {
    backgroundColor: "blue",
    paddingVertical: 12,
    paddingHorizontal: 25,
    borderRadius: 25,
    width: "100%",
    alignItems: "center",
    marginBottom: 20,
  },
  buttonText: {
    color: "#fff",
    fontWeight: "bold",
  },
  backButton: {
    marginTop: 10,
  },
  backButtonText: {
    color: "#003580",
    textDecorationLine: "underline",
  },

// TELA CADASTRO 
containerCadastro: {
  flex: 1,
  padding: 10,
  justifyContent: 'center',
  backgroundColor: 'white',
},
tituloCadastro: {
  fontSize: 28,
  fontWeight: 'bold',
  marginBottom: 20,
  textAlign: 'center',
  color: '#000', 
},
inputCadastro: {
  backgroundColor: '#FFFFFF',
  padding: 12,
  borderWidth: 1,
  borderColor: '#000',
  borderRadius: 8,
  marginBottom: 12,
  color: '#333', 
},
buttonContainer: {
  marginTop: 10,
  borderRadius: 8,
  overflow: 'hidden',
},
buttonCadastro: {
  backgroundColor: '#007BFF',
  paddingVertical: 14,
  justifyContent: 'center',
  alignItems: 'center',
  borderRadius: 8,
},


// TELA MAIN
container2: {
    flex: 1,
    backgroundColor: '#f4f4f4',
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 100,
},
  headermain: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
    paddingTop: 5,
  },
  avatar: {
    width: 70,
    height: 70,
    borderRadius: 18,
    marginRight: 15,
  },
  ola: {
    fontSize: 16,
    color: '#555',
    marginBottom: 2,
  },
  nome: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
  },
  icon: {
    marginLeft: 'auto',
  },
  cardCarga: {
    backgroundColor: '#FFF',
    margin: 16,
    padding: 16,
    borderRadius: 10,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  cargaInfo: {
    flex: 1,
    marginRight: 15,
  },
  progressoContainer: {
    height: 6,
    backgroundColor: '#f0f0f0',
    borderRadius: 3,
    marginVertical: 8,
    overflow: 'hidden',
  },
  progressoBarra: {
    height: '100%',
    backgroundColor: '#007bff',
    borderRadius: 3,
  },
  subInfoContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginTop: 8,
  },
  subInfoItem: {
    backgroundColor: '#e3f2fd',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
  },
  proximoRegistroHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  tempoRegistroHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  semRegistrosContainer: {
    backgroundColor: '#FFF',
    margin: 16,
    padding: 16,
    borderRadius: 10,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    justifyContent: 'center',
    alignItems: 'center',
  },
  dataHeaderContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  dataHeader: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  registroTipoContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
    gap: 6,
  },
  registroStatusContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  tituloCard: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 12,
  },
  valorCard: {
    fontSize: 22,
    fontWeight: 'bold',
  },
  subInfo: {
    backgroundColor: '#22C55E',
    alignSelf: 'flex-start',
    paddingHorizontal: 8,
    paddingVertical: 2,
    color: 'white',
    borderRadius: 6,
    marginTop: 4,
  },
  filtro: {
    backgroundColor: '#FFF',
    margin: 16,
    padding: 16,
    borderRadius: 10,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  ordenarPor: {
    fontSize: 14,
    color: '#333',
  },
  dropDown: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  lista: {
    flex: 1,
    marginBottom: 20,
  },
  cardRegistro: {
    backgroundColor: '#FFF',
    marginVertical: 8,
    padding: 16,
    borderRadius: 10,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    flexDirection: 'row',
    alignItems: 'center',
  },
  dataBolinha: {
    backgroundColor: '#0A3D62',
    borderRadius: 50,
    width: 60,
    height: 60,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  dataTexto: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 16,
  },
  infoRegistro: {
    fontSize: 14,
    marginBottom: 4,
    color: '#444',
    lineHeight: 20,
  },
  btnRegistrar: {
    backgroundColor: '#1B4FBA',
    paddingVertical: 15,
    borderRadius: 25,
    alignItems: 'center',
    marginBottom: 15,
  },
  textoBtn: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 16,
  },
  menu: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingVertical: 10,
    backgroundColor: '#fff',
  },
// modal 
modalContainer: {
  flex: 1,
  justifyContent: 'center',
  alignItems: 'center',
  backgroundColor: 'rgba(0, 0, 0, 0.5)',
},
modalContent: {
  backgroundColor: 'white',
  padding: 24,
  borderRadius: 16,
  alignItems: 'center',
  width: '85%',
  elevation: 5,
  shadowColor: '#000',
  shadowOffset: { width: 0, height: 2 },
  shadowOpacity: 0.25,
  shadowRadius: 4,
},
modalTitle: {
  fontSize: 20,
  fontWeight: 'bold',
  color: '#333',
  marginBottom: 20,
  textAlign: 'center',
},
modalButton: {
  width: '100%',
  paddingVertical: 14,
  paddingHorizontal: 20,
  borderRadius: 12,
  marginBottom: 12,
  flexDirection: 'row',
  alignItems: 'center',
  justifyContent: 'center',
  backgroundColor: '#f8f9fa',
},
modalButtonHighlight: {
  backgroundColor: '#e3f2fd',
  borderWidth: 2,
  borderColor: '#007bff',
},
modalButtonText: {
  fontSize: 16,
  fontWeight: '600',
  color: '#333',
  marginLeft: 8,
},
modalButtonCancel: {
  backgroundColor: '#f8f9fa',
  marginTop: 8,
},
modalIcon: {
  marginRight: 8,
},
// Estilos para mensagem de confirmação
confirmacaoContainer: {
  backgroundColor: 'white',
  padding: 24,
  borderRadius: 16,
  alignItems: 'center',
  width: '85%',
  elevation: 5,
  shadowColor: '#000',
  shadowOffset: { width: 0, height: 2 },
  shadowOpacity: 0.25,
  shadowRadius: 4,
},
confirmacaoIcon: {
  marginBottom: 16,
},
confirmacaoTitulo: {
  fontSize: 20,
  fontWeight: 'bold',
  color: '#333',
  marginBottom: 8,
  textAlign: 'center',
},
confirmacaoMensagem: {
  fontSize: 16,
  color: '#666',
  textAlign: 'center',
  marginBottom: 24,
},
confirmacaoBotao: {
  backgroundColor: '#007bff',
  paddingVertical: 12,
  paddingHorizontal: 24,
  borderRadius: 12,
  width: '100%',
  alignItems: 'center',
},
confirmacaoBotaoTexto: {
  color: 'white',
  fontSize: 16,
  fontWeight: '600',
},

// Estilos para a tela de registro de ponto
proximoRegistro: {
  backgroundColor: '#FFF',
  margin: 16,
  padding: 16,
  borderRadius: 10,
  elevation: 3,
  shadowColor: '#000',
  shadowOffset: { width: 0, height: 2 },
  shadowOpacity: 0.1,
  shadowRadius: 4,
  justifyContent: 'center',
},
proximoRegistroTitulo: {
  fontSize: 14,
  color: '#666',
  marginBottom: 4,
},
proximoRegistroValor: {
  fontSize: 18,
  fontWeight: 'bold',
  color: '#007bff',
},
tempoRegistro: {
  backgroundColor: '#FFF',
  margin: 16,
  padding: 16,
  borderRadius: 10,
  elevation: 3,
  shadowColor: '#000',
  shadowOffset: { width: 0, height: 2 },
  shadowOpacity: 0.1,
  shadowRadius: 4,
  justifyContent: 'center',
},
tempoRegistroTitulo: {
  fontSize: 14,
  color: '#666',
  marginBottom: 4,
},
tempoRegistroValor: {
  fontSize: 18,
  fontWeight: 'bold',
  color: '#333',
},
listaRegistros: {
    flex: 1,
    backgroundColor: '#fff',
    borderRadius: 15,
    marginTop: 10,
    marginBottom: 20,
    padding: 15,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
},
dataBolinha: {
    width: 45,
    height: 45,
    borderRadius: 22.5,
    backgroundColor: '#007bff',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
},
dataTexto: {
    color: '#fff',
    fontSize: 13,
    fontWeight: 'bold',
},
registroInfo: {
    flex: 1,
    marginLeft: 12,
},
semRegistros: {
    textAlign: 'center',
    padding: 20,
    color: '#666',
    fontSize: 16,
    fontStyle: 'italic',
},
menuInferior: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    paddingVertical: 15,
    borderTopWidth: 1,
    borderTopColor: '#eee',
    backgroundColor: '#fff',
    position: 'absolute',
    bottom: 20,
    left: 0,
    right: 0,
    paddingHorizontal: 20,
    borderRadius: 20,
    marginHorizontal: 10,
    elevation: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
},
grupoDia: {
    marginBottom: 20,
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 15,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
},
cardNotificacao: {
  backgroundColor: '#FFF',
  marginHorizontal: 16,
  marginVertical: 8,
  padding: 16,
  borderRadius: 10,
  elevation: 3,
  shadowColor: '#000',
  shadowOffset: { width: 0, height: 2 },
  shadowOpacity: 0.1,
  shadowRadius: 4,
  flexDirection: 'row',
  alignItems: 'center',
},
notificacaoIcone: {
  marginRight: 16,
},
notificacaoConteudo: {
  flex: 1,
},
notificacaoTitulo: {
  fontSize: 16,
  fontWeight: 'bold',
  color: '#333',
  marginBottom: 4,
},
notificacaoMensagem: {
  fontSize: 14,
  color: '#666',
  marginBottom: 8,
},
notificacaoData: {
  fontSize: 12,
  color: '#999',
},
cardConfig: {
  backgroundColor: '#FFF',
  margin: 16,
  padding: 16,
  borderRadius: 10,
  elevation: 3,
  shadowColor: '#000',
  shadowOffset: { width: 0, height: 2 },
  shadowOpacity: 0.1,
  shadowRadius: 4,
},
configItem: {
  flexDirection: 'row',
  alignItems: 'center',
  justifyContent: 'space-between',
  paddingVertical: 12,
  borderBottomWidth: 1,
  borderBottomColor: '#f0f0f0',
},
configItemLeft: {
  flexDirection: 'row',
  alignItems: 'center',
},
configItemText: {
  fontSize: 16,
  color: '#333',
  marginLeft: 12,
},

});

export default styles;
