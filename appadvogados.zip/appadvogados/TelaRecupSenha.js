import React, { useState } from "react";
import { View, Text, TextInput, TouchableOpacity, StyleSheet, SafeAreaView, Alert, ActivityIndicator } from "react-native";
import { MaterialCommunityIcons } from 'react-native-vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import styles from './styles'; // Certifique-se de ter esse arquivo de estilos
import { NavigationContainer } from '@react-navigation/native';
import { auth } from './firebaseConfig';

export default function TelaRecuSenha({navigation}) {
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);

  const handleResetPassword = async () => {
    if (!email.trim()) {
      Alert.alert('Erro', 'Por favor, insira seu email.');
      return;
    }

    setLoading(true);
    try {
      await auth.sendPasswordResetEmail(email);
      Alert.alert(
        'Email Enviado',
        'Enviamos um link de recuperação para seu email. Por favor, verifique sua caixa de entrada.',
        [
          {
            text: 'OK',
            onPress: () => navigation.navigate('TelaLogin')
          }
        ]
      );
    } catch (error) {
      console.error('Erro ao enviar email de recuperação:', error);
      let mensagemErro = 'Ocorreu um erro ao enviar o email de recuperação.';
      
      switch (error.code) {
        case 'auth/invalid-email':
          mensagemErro = 'O email fornecido é inválido.';
          break;
        case 'auth/user-not-found':
          mensagemErro = 'Não existe uma conta com este email.';
          break;
        case 'auth/too-many-requests':
          mensagemErro = 'Muitas tentativas. Por favor, tente novamente mais tarde.';
          break;
      }
      
      Alert.alert('Erro', mensagemErro);
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
    <LinearGradient
        // Background Linear Gradient
        colors={['rgb(255,255,255)', 'transparent']}
        style={styles.background2}
      />
      
      <View style={styles.header}>
      
        <Text style={styles.headerText}>ESQUECEU SUA SENHA?</Text>
      </View>

      <View style={styles.content}>
          
        <Text style={styles.iconRecu}></Text>

        <Text style={styles.title}>Problemas para fazer login?</Text>
        <Text style={styles.subtitle}>
          Digite seu e-mail e enviaremos um link para redefinir sua senha.
        </Text>

        <TextInput
          style={styles.input}
          placeholder="Email"
          value={email}
          onChangeText={setEmail}
          keyboardType="email-address"
          autoCapitalize="none"
          editable={!loading}
        />

        <TouchableOpacity 
          style={[styles.button, loading && { opacity: 0.7 }]} 
          onPress={handleResetPassword}
          disabled={loading}
        >
          {loading ? (
            <ActivityIndicator color="#FFFFFF" />
          ) : (
            <Text style={styles.buttonText}>Redefinir senha</Text>
          )}
        </TouchableOpacity>

        <TouchableOpacity 
          style={styles.backButton}
          onPress={() => navigation.navigate('TelaLogin')}
          disabled={loading}
        >
          <Text style={styles.backButtonText}>Retornar à página de login</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}
