import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from './AuthContext';

const TelaPerfil = ({ navigation }) => {
  const { userData } = useAuth();

  // Função para calcular horas por dia baseado na carga horária mensal
  const calcularHorasPorDia = (cargaHorariaMensal) => {
    const diasUteis = 22; // Média de dias úteis por mês
    return (parseInt(cargaHorariaMensal) / diasUteis).toFixed(1);
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Ionicons name="person-circle-outline" size={80} color="#007bff" />
        <Text style={styles.nome}>{userData?.nomeCompleto || userData?.nomeUsuario}</Text>
        <Text style={styles.email}>{userData?.email}</Text>
      </View>

      <View style={styles.card}>
        <Text style={styles.tituloCard}>Carga Horária</Text>
        <Text style={styles.valorCard}>{userData?.cargaHorariamensal || '0'} horas/mês</Text>
        <View style={styles.infoContainer}>
          <View style={styles.infoItem}>
            <Text style={styles.infoLabel}>Horas por Dia</Text>
            <Text style={styles.infoValor}>
              {calcularHorasPorDia(userData?.cargaHorariamensal || '0')}h
            </Text>
          </View>
          <View style={styles.infoItem}>
            <Text style={styles.infoLabel}>Status</Text>
            <Text style={styles.infoValor}>Ativo</Text>
          </View>
        </View>
      </View>

      <View style={styles.card}>
        <Text style={styles.tituloCard}>Informações do Estágio</Text>
        <View style={styles.infoContainer}>
          <View style={styles.infoItem}>
            <Text style={styles.infoLabel}>Tipo</Text>
            <Text style={styles.infoValor}>Estagiário</Text>
          </View>
          <View style={styles.infoItem}>
            <Text style={styles.infoLabel}>Registro</Text>
            <Text style={styles.infoValor}>
              {userData?.criadoEm ? new Date(userData.criadoEm.toDate()).toLocaleDateString('pt-BR') : 'N/A'}
            </Text>
          </View>
        </View>
      </View>

      <TouchableOpacity
        style={styles.botao}
        onPress={() => navigation.navigate('EditarPerfil')}
      >
        <Text style={styles.textoBotao}>Editar Perfil</Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F0F0F0',
  },
  header: {
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#FFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
  },
  nome: {
    fontSize: 24,
    fontWeight: 'bold',
    marginTop: 10,
    color: '#333',
  },
  email: {
    fontSize: 16,
    color: '#666',
    marginTop: 5,
  },
  card: {
    backgroundColor: '#FFF',
    margin: 16,
    padding: 16,
    borderRadius: 10,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  tituloCard: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 12,
  },
  valorCard: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 12,
  },
  infoContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 8,
  },
  infoItem: {
    flex: 1,
  },
  infoLabel: {
    fontSize: 14,
    color: '#666',
    marginBottom: 4,
  },
  infoValor: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  botao: {
    backgroundColor: '#007bff',
    margin: 16,
    padding: 16,
    borderRadius: 10,
    alignItems: 'center',
  },
  textoBotao: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default TelaPerfil;