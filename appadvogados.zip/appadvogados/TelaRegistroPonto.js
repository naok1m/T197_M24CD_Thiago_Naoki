import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  Image,
  Alert,
  ActivityIndicator,
  Modal
} from 'react-native';
import { Ionicons, Feather, FontAwesome } from '@expo/vector-icons';
import styles from './styles'; 
import { firebase, auth, db } from './firebaseConfig';
import { useAuth } from './AuthContext';

export default function TelaRegistroPonto({ navigation }) {
  const { currentUser, userData, loadingAuth, recarregarDadosUsuario } = useAuth();
  const [registros, setRegistros] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadingAction, setLoadingAction] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [proximoRegistro, setProximoRegistro] = useState(null);
  const [tempoDesdeUltimoRegistro, setTempoDesdeUltimoRegistro] = useState(null);
  const [cargaHorariaAtual, setCargaHorariaAtual] = useState({
    horasTrabalhadas: 0,
    horasMensais: 0,
    diasTrabalhados: 0,
    diasNoMes: 0,
    horasPorDia: 0
  });

  // Verifica autenticação e redireciona se necessário
  useEffect(() => {
    console.log('TelaRegistroPonto: Verificando autenticação', {
      currentUser: !!currentUser,
      userData: !!userData,
      loadingAuth
    });

    if (!loadingAuth) {
      if (!currentUser) {
        console.log('TelaRegistroPonto: Usuário não autenticado, redirecionando para login');
        navigation.replace('TelaLogin');
      } else if (!userData) {
        console.log('TelaRegistroPonto: Dados do usuário não encontrados, tentando recarregar');
        recarregarDadosUsuario();
      } else {
        console.log('TelaRegistroPonto: Usuário autenticado, carregando dados');
        carregarRegistrosPonto(userData.uid, userData.cargaHorariamensal);
      }
    }
  }, [currentUser, userData, loadingAuth]);

  // Atualiza o tempo desde o último registro
  useEffect(() => {
    const timer = setInterval(() => {
      if (registros.length > 0) {
        const ultimoRegistro = registros[0].registros[registros[0].registros.length - 1];
        const ultimoTimestamp = ultimoRegistro.timestamp?.toDate?.() || new Date(ultimoRegistro.timestamp);
        const agora = new Date();
        
        if (ultimoTimestamp instanceof Date && !isNaN(ultimoTimestamp)) {
          const diff = Math.floor((agora - ultimoTimestamp) / 1000); // diferença em segundos
          const horas = Math.floor(diff / 3600);
          const minutos = Math.floor((diff % 3600) / 60);
          setTempoDesdeUltimoRegistro(`${horas}h ${minutos}m`);
        } else {
          setTempoDesdeUltimoRegistro('0h 0m');
        }
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [registros]);

  // Determina o próximo registro esperado
  useEffect(() => {
    if (registros.length > 0) {
      const hoje = new Date().toLocaleDateString('pt-BR');
      const registrosHoje = registros.filter(r => r.data === hoje);
      
      if (registrosHoje.length === 0) {
        setProximoRegistro('entrada');
      } else if (registrosHoje.length === 1 && registrosHoje[0].tipo === 'entrada') {
        setProximoRegistro('intervalo');
      } else if (registrosHoje.length === 2 && registrosHoje[1].tipo === 'intervalo') {
        setProximoRegistro('saida');
      } else {
        setProximoRegistro(null);
      }
    } else {
      setProximoRegistro('entrada');
    }
  }, [registros]);

  // Função para carregar os registros de ponto
  const carregarRegistrosPonto = async (userId, cargaHorariamensal) => {
    if (!userId) {
      console.error('TelaRegistroPonto: userId não fornecido');
      setLoading(false);
      return;
    }

    try {
      console.log('TelaRegistroPonto: Carregando registros para o usuário:', userId);
      
      const registrosRef = db.collection('registros_ponto')
        .where('userId', '==', userId);

      const snapshot = await registrosRef.get();
      console.log('TelaRegistroPonto: Número de registros encontrados:', snapshot.size);
      
      const registrosList = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));

      console.log('TelaRegistroPonto: Dados dos registros:', registrosList);

      // Ordena os registros por timestamp (do mais antigo para o mais recente)
      const registrosOrdenados = registrosList.sort((a, b) => {
        const timestampA = a.timestamp?.toDate?.() || new Date(a.timestamp);
        const timestampB = b.timestamp?.toDate?.() || new Date(b.timestamp);
        return timestampA - timestampB; // Invertido para ordem cronológica
      });
      
      // Agrupa registros por dia
      const registrosPorDia = {};
      registrosOrdenados.forEach(registro => {
        if (!registrosPorDia[registro.data]) {
          registrosPorDia[registro.data] = [];
        }
        registrosPorDia[registro.data].push(registro);
      });

      // Converte para array e ordena por data (mais recente primeiro)
      const registrosAgrupados = Object.entries(registrosPorDia)
        .map(([data, registros]) => ({
          data,
          registros: registros.sort((a, b) => {
            const horaA = a.hora.split(':').map(Number);
            const horaB = b.hora.split(':').map(Number);
            return (horaA[0] * 60 + horaA[1]) - (horaB[0] * 60 + horaB[1]);
          })
        }))
        .sort((a, b) => {
          const dataA = a.data.split('/').reverse().join('-');
          const dataB = b.data.split('/').reverse().join('-');
          return new Date(dataB) - new Date(dataA);
        });
      
      console.log('TelaRegistroPonto: Registros agrupados:', registrosAgrupados);
      
      setRegistros(registrosAgrupados);
      calcularCargaHoraria(registrosOrdenados, cargaHorariamensal);
    } catch (error) {
      console.error('TelaRegistroPonto: Erro ao carregar registros:', error);
      Alert.alert('Erro', 'Não foi possível carregar o histórico de pontos');
    } finally {
      setLoading(false);
    }
  };

  const validarRegistro = (tipo) => {
    const agora = new Date();
    const horaAtual = agora.getHours();
    const minutosAtuais = agora.getMinutes();
    
    // Verifica horário comercial (8h às 18h)
    if (horaAtual < 8 || (horaAtual === 18 && minutosAtuais > 0) || horaAtual > 18) {
      Alert.alert(
        'Fora do Horário Comercial',
        'Os registros só podem ser feitos entre 8h e 18h.',
        [{ text: 'OK' }]
      );
      return false;
    }

    // Verifica intervalo mínimo entre registros (5 minutos)
    if (registros.length > 0) {
      const registrosHoje = registros.filter(r => r.data === agora.toLocaleDateString('pt-BR'));
      if (registrosHoje.length > 0) {
        const ultimoRegistro = registrosHoje[0].registros[registrosHoje[0].registros.length - 1];
        const ultimoTimestamp = ultimoRegistro.timestamp?.toDate?.() || new Date(ultimoRegistro.timestamp);
        const diffMinutos = Math.floor((agora - ultimoTimestamp) / (1000 * 60));
        
        if (diffMinutos < 5) {
          Alert.alert(
            'Intervalo Mínimo',
            'É necessário aguardar 5 minutos entre os registros.',
            [{ text: 'OK' }]
          );
          return false;
        }
      }
    }

    // Verifica sequência correta dos registros
    const hoje = agora.toLocaleDateString('pt-BR');
    const registrosHoje = registros.filter(r => r.data === hoje);
    
    if (registrosHoje.length > 0) {
      const registrosDoDia = registrosHoje[0].registros;
      const temEntrada = registrosDoDia.some(r => r.tipo === 'entrada');
      const temIntervalo = registrosDoDia.some(r => r.tipo === 'intervalo');
      const temSaida = registrosDoDia.some(r => r.tipo === 'saida');

      if (tipo === 'saida' && !temEntrada) {
        Alert.alert(
          'Registro Inválido',
          'Você precisa registrar uma entrada antes de registrar a saída.',
          [{ text: 'OK' }]
        );
        return false;
      }

      if (tipo === 'intervalo' && !temEntrada) {
        Alert.alert(
          'Registro Inválido',
          'Você precisa registrar uma entrada antes de registrar o intervalo.',
          [{ text: 'OK' }]
        );
        return false;
      }

      if (tipo === 'saida' && temSaida) {
        Alert.alert(
          'Registro Inválido',
          'Você já registrou a saída hoje.',
          [{ text: 'OK' }]
        );
        return false;
      }

      if (tipo === 'intervalo' && temIntervalo) {
        Alert.alert(
          'Registro Inválido',
          'Você já registrou o intervalo hoje.',
          [{ text: 'OK' }]
        );
        return false;
      }

      if (tipo === 'entrada' && temEntrada) {
        Alert.alert(
          'Registro Inválido',
          'Você já registrou a entrada hoje.',
          [{ text: 'OK' }]
        );
        return false;
      }
    }

    return true;
  };

  const registrarPonto = async (tipo) => {
    if (!userData) {
      Alert.alert('Erro', 'Dados do usuário não carregados. Por favor, aguarde ou tente novamente.');
      return;
    }

    if (!validarRegistro(tipo)) {
      return;
    }

    try {
      setLoadingAction(true);
      setModalVisible(false);
      
      const timestamp = firebase.firestore.FieldValue.serverTimestamp();
      const dataAtual = new Date();
      const dataFormatada = dataAtual.toLocaleDateString('pt-BR');
      const horaFormatada = dataAtual.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });

      // Verifica se já existe registro para hoje do mesmo tipo
      const registrosHojeQuery = db.collection('registros_ponto')
        .where('userId', '==', userData.uid)
        .where('data', '==', dataFormatada)
        .where('tipo', '==', tipo);

      const registrosHojeSnapshot = await registrosHojeQuery.get();

      if (!registrosHojeSnapshot.empty) {
        Alert.alert('Aviso', `Você já registrou ${tipo} hoje!`);
        setLoadingAction(false);
        return;
      }

      // Cria o novo registro
      const novoRegistro = {
        userId: userData.uid,
        nomeUsuario: userData.nomeCompleto || userData.nomeUsuario || 'Usuário Desconhecido',
        timestamp: timestamp,
        data: dataFormatada,
        hora: horaFormatada,
        tipo: tipo,
        status: 'pendente'
      };

      await db.collection('registros_ponto').add(novoRegistro);

      Alert.alert('Sucesso', `Ponto de ${tipo} registrado com sucesso!`);
      await carregarRegistrosPonto(userData.uid, userData.cargaHorariamensal);

    } catch (error) {
      console.error('Erro ao registrar ponto:', error);
      Alert.alert('Erro', 'Não foi possível registrar o ponto. Tente novamente.');
    } finally {
      setLoadingAction(false);
    }
  };

  // Função para calcular a carga horária
  const calcularCargaHoraria = (registros, cargaHorariamensal) => {
    const hoje = new Date();
    const primeiroDiaMes = new Date(hoje.getFullYear(), hoje.getMonth(), 1);
    const ultimoDiaMes = new Date(hoje.getFullYear(), hoje.getMonth() + 1, 0);
    
    // Filtra registros do mês atual
    const registrosMes = registros.filter(registro => {
      const dataRegistro = registro.timestamp?.toDate();
      return dataRegistro >= primeiroDiaMes && dataRegistro <= ultimoDiaMes;
    });

    // Calcula dias úteis do mês (excluindo finais de semana)
    const diasUteis = Array.from(
      { length: ultimoDiaMes.getDate() },
      (_, i) => new Date(hoje.getFullYear(), hoje.getMonth(), i + 1)
    ).filter(data => data.getDay() !== 0 && data.getDay() !== 6).length;

    // Converte carga horária para número
    const cargaHorariaNum = parseInt(cargaHorariamensal) || 0;
    
    // Calcula horas por dia
    const horasPorDia = diasUteis > 0 ? cargaHorariaNum / diasUteis : 0;

    // Agrupa registros por dia
    const registrosPorDia = {};
    registrosMes.forEach(registro => {
      const data = registro.data;
      if (!registrosPorDia[data]) {
        registrosPorDia[data] = [];
      }
      registrosPorDia[data].push(registro);
    });

    // Calcula horas trabalhadas apenas para dias com entrada e saída
    let diasTrabalhados = 0;
    Object.values(registrosPorDia).forEach(registrosDoDia => {
      const temEntrada = registrosDoDia.some(r => r.tipo === 'entrada');
      const temSaida = registrosDoDia.some(r => r.tipo === 'saida');
      
      if (temEntrada && temSaida) {
        diasTrabalhados++;
      }
    });

    // Calcula horas trabalhadas baseado nos dias completos
    const horasTrabalhadas = diasTrabalhados * horasPorDia;

    setCargaHorariaAtual({
      horasTrabalhadas: Math.round(horasTrabalhadas),
      horasMensais: cargaHorariaNum,
      diasTrabalhados: diasTrabalhados,
      diasNoMes: diasUteis,
      horasPorDia: Math.round(horasPorDia * 10) / 10
    });
  };

  // Mostra loading enquanto carrega os dados
  if (loadingAuth || loading) {
    return (
      <View style={[styles.container2, { justifyContent: 'center', alignItems: 'center' }]}>
        <ActivityIndicator size="large" color="#007bff" />
        <Text style={{ marginTop: 10 }}>Carregando dados...</Text>
      </View>
    );
  }

  // Se não há usuário logado
  if (!currentUser || !userData) {
    return (
      <View style={[styles.container2, { justifyContent: 'center', alignItems: 'center' }]}>
        <Text style={{ textAlign: 'center', padding: 20 }}>
          Sessão encerrada. Por favor, faça login novamente.
        </Text>
        <TouchableOpacity
          style={styles.btnRegistrar}
          onPress={() => navigation.replace('TelaLogin')}
        >
          <Text style={styles.textoBtn}>IR PARA LOGIN</Text>
        </TouchableOpacity>
      </View>
    );
  }
  
  // Se chegou aqui, currentUser e userData estão disponíveis
  return (
    <View style={styles.container2}>
      <View style={styles.headermain}>
        <Image
          source={require('./assets/real-logo.png')} // Certifique-se que o caminho está correto
          style={styles.avatar}
        />
        <View>
          <Text style={styles.ola}>Olá,</Text>
          <Text style={styles.nome}>{userData?.nomeUsuario || 'Usuário'}!</Text>
        </View>
      </View>

      {/* CARGA HORÁRIA */}
      <Text style={[styles.tituloCard, { marginLeft: 16, marginBottom: 8 }]}>Carga horária</Text>
      <View style={[styles.cardCarga, { height: 100 }]}>
        <View style={styles.cargaInfo}>
          <View style={styles.progressoContainer}>
            <View style={[
              styles.progressoBarra,
              { width: `${(cargaHorariaAtual.horasTrabalhadas / cargaHorariaAtual.horasMensais) * 100}%` }
            ]} />
          </View>
          <Text style={styles.valorCard}>
            {cargaHorariaAtual.horasTrabalhadas}/{cargaHorariaAtual.horasMensais}h
          </Text>
          <View style={styles.subInfoContainer}>
            <View style={styles.subInfoItem}>
              <Text style={styles.subInfo}>
                {cargaHorariaAtual.diasTrabalhados}/{cargaHorariaAtual.diasNoMes} dias
              </Text>
            </View>
            <View style={styles.subInfoItem}>
              <Text style={styles.subInfo}>
                {cargaHorariaAtual.horasPorDia}h/dia
              </Text>
            </View>
          </View>
        </View>
        <Feather name="calendar" size={35} color="#007bff" />
      </View>

      {/* PRÓXIMO REGISTRO */}
      {proximoRegistro && (
        <View style={[styles.proximoRegistro, { height: 100 }]}>
          <View style={styles.proximoRegistroHeader}>
            <Ionicons name="time-outline" size={24} color="#007bff" />
            <Text style={styles.proximoRegistroTitulo}>Próximo registro:</Text>
          </View>
          <Text style={styles.proximoRegistroValor}>
            {proximoRegistro.toUpperCase()}
          </Text>
        </View>
      )}

      {/* TEMPO DESDE ÚLTIMO REGISTRO */}
      {tempoDesdeUltimoRegistro && (
        <View style={[styles.tempoRegistro, { height: 80 }]}>
          <View style={styles.tempoRegistroHeader}>
            <Ionicons name="hourglass-outline" size={24} color="#007bff" />
            <Text style={styles.tempoRegistroTitulo}>Tempo desde último registro:</Text>
          </View>
          <Text style={styles.tempoRegistroValor}>{tempoDesdeUltimoRegistro}</Text>
        </View>
      )}

      {/* LISTA DE REGISTROS */}
      <ScrollView style={styles.listaRegistros}>
        {registros.length === 0 ? (
          <View style={[styles.semRegistrosContainer, { height: 200 }]}>
            <Ionicons name="document-text-outline" size={48} color="#ccc" />
            <Text style={styles.semRegistros}>Nenhum ponto registrado hoje.</Text>
          </View>
        ) : (
          registros
            .filter(grupo => grupo.data === new Date().toLocaleDateString('pt-BR'))
            .map((grupo) => (
              <View key={grupo.data} style={styles.grupoDia}>
                <View style={[styles.dataHeaderContainer, { marginBottom: 8, paddingBottom: 4 }]}>
                  <Ionicons name="calendar-outline" size={20} color="#007bff" style={{ marginRight: 8 }} />
                  <Text style={[styles.dataHeader, { marginBottom: 0 }]}>Registros de Hoje</Text>
                </View>
                {grupo.registros.map((registro) => (
                  <View key={registro.id} style={[styles.cardRegistro, { height: 100 }]}>
                    <View style={styles.dataBolinha}>
                      <Text style={styles.dataTexto}>{registro.hora}</Text>
                    </View>
                    <View style={styles.registroInfo}>
                      <View style={styles.registroTipoContainer}>
                        <Ionicons 
                          name={
                            registro.tipo === 'entrada' ? 'log-in-outline' :
                            registro.tipo === 'saida' ? 'log-out-outline' : 'time-outline'
                          } 
                          size={16} 
                          color={
                            registro.tipo === 'entrada' ? '#4CAF50' :
                            registro.tipo === 'saida' ? '#F44336' : '#FF9800'
                          }
                        />
                        <Text style={[
                          styles.infoRegistro,
                          { 
                            color: registro.tipo === 'entrada' ? '#4CAF50' : 
                                   registro.tipo === 'saida' ? '#F44336' : '#FF9800',
                            fontWeight: 'bold'
                          }
                        ]}>
                          {registro.tipo.toUpperCase()}
                        </Text>
                      </View>
                      <View style={styles.registroStatusContainer}>
                        <Ionicons 
                          name={
                            registro.status === 'aprovado' ? 'checkmark-circle-outline' :
                            registro.status === 'rejeitado' ? 'close-circle-outline' : 'time-outline'
                          } 
                          size={16} 
                          color={
                            registro.status === 'aprovado' ? '#4CAF50' :
                            registro.status === 'rejeitado' ? '#F44336' : '#FF9800'
                          }
                        />
                        <Text style={[
                          styles.infoRegistro,
                          { 
                            color: registro.status === 'aprovado' ? '#4CAF50' : 
                                   registro.status === 'rejeitado' ? '#F44336' : '#FF9800',
                            fontWeight: 'bold'
                          }
                        ]}>
                          {registro.status.toUpperCase()}
                        </Text>
                      </View>
                    </View>
                  </View>
                ))}
              </View>
            ))
        )}
      </ScrollView>

      {/* BOTÃO REGISTRAR */}
      <TouchableOpacity
        onPress={() => setModalVisible(true)}
        style={[styles.btnRegistrar, loadingAction && { opacity: 0.7 }]}
        disabled={loadingAction}
      >
        <Text style={styles.textoBtn}>
          {loadingAction ? 'REGISTRANDO...' : 'REGISTRAR PONTO'}
        </Text>
      </TouchableOpacity>

      {/* Modal de Seleção do Tipo de Registro */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Selecione o tipo de registro</Text>
            
            <TouchableOpacity
              style={[styles.modalButton, proximoRegistro === 'entrada' && styles.modalButtonHighlight]}
              onPress={() => registrarPonto('entrada')}
            >
              <Ionicons name="log-in-outline" size={24} color="#007bff" style={styles.modalIcon} />
              <Text style={styles.modalButtonText}>Entrada</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.modalButton, proximoRegistro === 'intervalo' && styles.modalButtonHighlight]}
              onPress={() => registrarPonto('intervalo')}
            >
              <Ionicons name="time-outline" size={24} color="#007bff" style={styles.modalIcon} />
              <Text style={styles.modalButtonText}>Intervalo</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.modalButton, proximoRegistro === 'saida' && styles.modalButtonHighlight]}
              onPress={() => registrarPonto('saida')}
            >
              <Ionicons name="log-out-outline" size={24} color="#007bff" style={styles.modalIcon} />
              <Text style={styles.modalButtonText}>Saída</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.modalButton, styles.modalButtonCancel]}
              onPress={() => setModalVisible(false)}
            >
              <Ionicons name="close-outline" size={24} color="#666" style={styles.modalIcon} />
              <Text style={[styles.modalButtonText, { color: '#666' }]}>Cancelar</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Modal de Confirmação */}
      <Modal
        animationType="fade"
        transparent={true}
        visible={loadingAction}
        onRequestClose={() => {}}
      >
        <View style={styles.modalContainer}>
          <View style={styles.confirmacaoContainer}>
            <ActivityIndicator size="large" color="#007bff" style={styles.confirmacaoIcon} />
            <Text style={styles.confirmacaoTitulo}>Registrando ponto...</Text>
            <Text style={styles.confirmacaoMensagem}>Por favor, aguarde enquanto processamos seu registro.</Text>
          </View>
        </View>
      </Modal>

      {/* MENU INFERIOR */}
      <View style={styles.menuInferior}>
        <TouchableOpacity>
          <FontAwesome name="home" size={28} color="#007bff" />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('TelaHistorico')}>
          <Ionicons name="stats-chart-outline" size={28} color="gray" />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('TelaNotificacoes')}>
          <Ionicons name="notifications-outline" size={28} color="gray" />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('TelaConfig')}>
          <Ionicons name="settings-outline" size={28} color="gray" />
        </TouchableOpacity>
      </View>
    </View>
  );
}
