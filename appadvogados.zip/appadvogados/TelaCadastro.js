import React, { useState } from 'react';
import { View, Text, TextInput, Button, Alert, TouchableOpacity, Modal, ScrollView, ActivityIndicator, TouchableWithoutFeedback, Keyboard } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import styles from './styles'; 
import { firebase, auth, db } from './firebaseConfig';


export default function CadastroScreen() {
  const navigation = useNavigation();
  const [nomeCompleto, setNomeCompleto] = useState('');
  const [nomeUsuario, setNomeUsuario] = useState('');
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [repetirSenha, setRepetirSenha] = useState('');
  const [cargaHorariamensal, setcargaHorariamensal] = useState('');
  const [modalVisible, setModalVisible] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});
  const [mostrarSenha, setMostrarSenha] = useState(false);

  const opcoesCargaHoraria = [
    { label: "120 horas (5h30min/dia)", value: "120" },
    { label: "150 horas (6h50min/dia)", value: "150" },
    { label: "180 horas (8h10min/dia)", value: "180" },
    { label: "200 horas (9h05min/dia)", value: "200" },
    { label: "300 horas", value: "300" }
  ];

  const validarEmail = (email) => {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
  };

  const validarCampos = () => {
    const novosErros = {};
    
    if (!nomeCompleto.trim()) novosErros.nomeCompleto = 'Nome completo é obrigatório';
    if (!nomeUsuario.trim()) novosErros.nomeUsuario = 'Nome de usuário é obrigatório';
    if (!email.trim()) novosErros.email = 'Email é obrigatório';
    else if (!validarEmail(email)) novosErros.email = 'Email inválido';
    if (senha.length < 6) novosErros.senha = 'A senha deve ter no mínimo 6 caracteres';
    if (senha !== repetirSenha) novosErros.repetirSenha = 'As senhas não coincidem';
    if (!cargaHorariamensal) novosErros.cargaHorariamensal = 'Selecione uma carga horária';

    setErrors(novosErros);
    return Object.keys(novosErros).length === 0;
  };

  async function handleCadastro() {
    if (!validarCampos()) {
      Alert.alert('Erro', 'Por favor, corrija os erros antes de continuar.');
      return;
    }

    setLoading(true);
    try {
      const { user } = await auth.createUserWithEmailAndPassword(email, senha);

      await user.sendEmailVerification();

      await db.collection('usuarios').doc(user.uid).set({
        nomeCompleto,
        nomeUsuario,
        email,
        cargaHorariamensal,
        criadoEm: firebase.firestore.FieldValue.serverTimestamp(),
        tipo: 'advogado',
        status: 'ativo'
      });

      Alert.alert(
        'Cadastro realizado com sucesso!',
        'Enviamos um email de verificação para você. Por favor, verifique sua caixa de entrada e faça login após confirmar seu email.',
        [
          {
            text: 'Ir para Login',
            onPress: () => {
              // Limpa os campos antes de navegar
              setNomeCompleto('');
              setNomeUsuario('');
              setEmail('');
              setSenha('');
              setRepetirSenha('');
              setcargaHorariamensal('');
              navigation.navigate('TelaLogin');
            }
          }
        ]
      );

    } catch (error) {
      console.error('Erro completo:', error);
      let mensagemErro = 'Ocorreu um erro no cadastro';
      
      switch (error.code) {
        case 'auth/email-already-in-use':
          mensagemErro = 'Este email já está em uso';
          break;
        case 'auth/invalid-email':
          mensagemErro = 'Email inválido';
          break;
        case 'auth/operation-not-allowed':
          mensagemErro = 'Operação não permitida';
          break;
        case 'auth/weak-password':
          mensagemErro = 'A senha é muito fraca. Use pelo menos 6 caracteres';
          break;
        default:
          mensagemErro = `Erro no cadastro: ${error.message}`;
      }
      
      Alert.alert('Erro no cadastro', mensagemErro);
    } finally {
      setLoading(false);
    }
  }

  const renderInput = (placeholder, value, setValue, secureTextEntry = false, error = null, keyboardType = 'default') => (
    <View style={{ width: '100%', marginBottom: 15 }}>
      <TextInput
        style={{
          ...styles.inputCadastro,
          borderColor: error ? '#FF375B' : '#aaa'
        }}
        placeholder={placeholder}
        value={value}
        onChangeText={setValue}
        secureTextEntry={secureTextEntry && !mostrarSenha}
        placeholderTextColor="#aaa"
        keyboardType={keyboardType}
      />
      {error && <Text style={{ color: '#FF375B', fontSize: 12, marginTop: 5 }}>{error}</Text>}
    </View>
  );

  return (
    <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
      <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
        <View style={{ ...styles.containerCadastro, padding: 20 }}>
          <Text style={{ ...styles.tituloCadastro, marginBottom: 30, fontSize: 24, fontWeight: 'bold' }}>
            Criar Conta
          </Text>

          {renderInput('Nome Completo', nomeCompleto, setNomeCompleto, false, errors.nomeCompleto)}
          {renderInput('Nome de Usuário', nomeUsuario, setNomeUsuario, false, errors.nomeUsuario)}
          {renderInput('Email', email, setEmail, false, errors.email, 'email-address')}
          
          <View style={{ width: '100%', marginBottom: 15 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <TextInput
                style={{
                  ...styles.inputCadastro,
                  flex: 1,
                  borderColor: errors.senha ? '#FF375B' : '#aaa'
                }}
                placeholder="Senha"
                value={senha}
                onChangeText={setSenha}
                secureTextEntry={!mostrarSenha}
                placeholderTextColor="#aaa"
              />
              <TouchableOpacity
                onPress={() => setMostrarSenha(!mostrarSenha)}
                style={{ position: 'absolute', right: 15 }}
              >
                <Text style={{ color: '#007AFF' }}>
                  {mostrarSenha ? 'Ocultar' : 'Mostrar'}
                </Text>
              </TouchableOpacity>
            </View>
            {errors.senha && <Text style={{ color: '#FF375B', fontSize: 12, marginTop: 5 }}>{errors.senha}</Text>}
          </View>

          {renderInput('Repetir Senha', repetirSenha, setRepetirSenha, true, errors.repetirSenha)}

          <TouchableOpacity
            style={{
              width: '100%',
              height: 50,
              borderWidth: 3,
              borderColor: errors.cargaHorariamensal ? '#FF375B' : "#aaa",
              borderRadius: 10,
              marginVertical: 10,
              backgroundColor: '#FFFFFF',
              justifyContent: 'center',
              paddingHorizontal: 10
            }}
            onPress={() => setModalVisible(true)}
          >
            <Text style={{ color: cargaHorariamensal ? '#000' : '#aaa' }}>
              {cargaHorariamensal 
                ? opcoesCargaHoraria.find(opt => opt.value === cargaHorariamensal)?.label 
                : "Selecione sua carga horária mensal"}
            </Text>
          </TouchableOpacity>
          {errors.cargaHorariamensal && 
            <Text style={{ color: '#FF375B', fontSize: 12, marginBottom: 15 }}>
              {errors.cargaHorariamensal}
            </Text>
          }

          <TouchableOpacity
            style={{
              backgroundColor: '#007AFF',
              paddingVertical: 15,
              borderRadius: 10,
              width: '100%',
              alignItems: 'center',
              marginTop: 20
            }}
            onPress={handleCadastro}
            disabled={loading}
          >
            {loading ? (
              <ActivityIndicator color="#FFFFFF" />
            ) : (
              <Text style={{ color: '#FFFFFF', fontSize: 16, fontWeight: 'bold' }}>
                Cadastrar
              </Text>
            )}
          </TouchableOpacity>

          <Modal
            animationType="slide"
            transparent={true}
            visible={modalVisible}
            onRequestClose={() => setModalVisible(false)}
          >
            <TouchableWithoutFeedback onPress={() => {
              Keyboard.dismiss();
              setModalVisible(false);
            }}>
              <View style={{
                flex: 1,
                justifyContent: 'center',
                alignItems: 'center',
                backgroundColor: 'rgba(0,0,0,0.5)'
              }}>
                <TouchableWithoutFeedback onPress={(e) => e.stopPropagation()}>
                  <View style={{
                    backgroundColor: 'white',
                    borderRadius: 16,
                    padding: 24,
                    width: '90%',
                    maxHeight: '80%',
                    elevation: 5,
                    shadowColor: '#000',
                    shadowOffset: { width: 0, height: 2 },
                    shadowOpacity: 0.25,
                    shadowRadius: 4,
                  }}>
                    <Text style={{
                      fontSize: 20,
                      fontWeight: 'bold',
                      color: '#333',
                      marginBottom: 20,
                      textAlign: 'center'
                    }}>
                      Selecione sua carga horária
                    </Text>
                    <ScrollView style={{ maxHeight: '80%' }}>
                      {opcoesCargaHoraria.map((opcao) => (
                        <TouchableOpacity
                          key={opcao.value}
                          style={{
                            padding: 16,
                            borderBottomWidth: 1,
                            borderBottomColor: '#f0f0f0',
                            backgroundColor: cargaHorariamensal === opcao.value ? '#e3f2fd' : 'transparent',
                            borderRadius: 8,
                            marginBottom: 8
                          }}
                          onPress={() => {
                            setcargaHorariamensal(opcao.value);
                            setModalVisible(false);
                          }}
                        >
                          <Text style={{ 
                            fontSize: 16,
                            color: cargaHorariamensal === opcao.value ? '#007bff' : '#333',
                            fontWeight: cargaHorariamensal === opcao.value ? 'bold' : 'normal'
                          }}>
                            {opcao.label}
                          </Text>
                        </TouchableOpacity>
                      ))}
                    </ScrollView>
                    <TouchableOpacity
                      style={{
                        marginTop: 20,
                        padding: 16,
                        backgroundColor: '#007bff',
                        borderRadius: 12,
                        alignItems: 'center',
                        elevation: 2,
                        shadowColor: '#000',
                        shadowOffset: { width: 0, height: 1 },
                        shadowOpacity: 0.2,
                        shadowRadius: 2,
                      }}
                      onPress={() => setModalVisible(false)}
                    >
                      <Text style={{ 
                        color: 'white',
                        fontSize: 16,
                        fontWeight: 'bold'
                      }}>
                        Fechar
                      </Text>
                    </TouchableOpacity>
                  </View>
                </TouchableWithoutFeedback>
              </View>
            </TouchableWithoutFeedback>
          </Modal>
        </View>
      </ScrollView>
    </TouchableWithoutFeedback>
  );
}