// screens/TelaHistorico.js

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  FlatList,
  StyleSheet,
  ActivityIndicator,
  TouchableOpacity,
} from 'react-native';
import { useAuth } from './AuthContext';
import { db } from './firebaseConfig';
import { Ionicons } from '@expo/vector-icons';

const TelaHistorico = () => {
  const { userData } = useAuth();
  const [registros, setRegistros] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filtroMes, setFiltroMes] = useState(new Date());

  useEffect(() => {
    if (userData) {
      carregarRegistros();
    }
  }, [userData, filtroMes]);

  const carregarRegistros = async () => {
    try {
      setLoading(true);
      const snapshot = await db
        .collection('registros_ponto')
        .where('userId', '==', userData.uid)
        .get();

      const registrosList = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));

      // Agrupa registros por dia
      const registrosPorDia = {};
      registrosList.forEach((registro) => {
        const data = registro.data;
        if (!registrosPorDia[data]) {
          registrosPorDia[data] = [];
        }
        registrosPorDia[data].push(registro);
      });

      // Converte para array e ordena por data
      const registrosOrdenados = Object.entries(registrosPorDia)
        .map(([data, registros]) => ({
          data,
          registros: registros.sort((a, b) => {
            const horaA = a.hora.split(':').map(Number);
            const horaB = b.hora.split(':').map(Number);
            return horaA[0] * 60 + horaA[1] - (horaB[0] * 60 + horaB[1]);
          }),
        }))
        .sort(
          (a, b) =>
            new Date(b.data.split('/').reverse().join('-')) -
            new Date(a.data.split('/').reverse().join('-'))
        );

      setRegistros(registrosOrdenados);
    } catch (error) {
      console.error('Erro ao carregar histórico:', error);
    } finally {
      setLoading(false);
    }
  };

  const mudarMes = (incremento) => {
    const novoMes = new Date(filtroMes);
    novoMes.setMonth(novoMes.getMonth() + incremento);
    setFiltroMes(novoMes);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'aprovado':
        return '#4CAF50';
      case 'rejeitado':
        return '#F44336';
      default:
        return '#FF9800';
    }
  };

  const renderItem = ({ item }) => (
    <View style={styles.diaContainer}>
      <Text style={styles.dataHeader}>{item.data}</Text>
      {item.registros.map((registro, index) => (
        <View key={registro.id} style={styles.registroContainer}>
          <View style={styles.registroInfo}>
            <Text style={styles.hora}>{registro.hora}</Text>
            <Text
              style={[
                styles.tipo,
                {
                  color:
                    registro.tipo === 'entrada'
                      ? '#4CAF50'
                      : registro.tipo === 'saida'
                      ? '#F44336'
                      : '#FF9800',
                },
              ]}>
              {registro.tipo.toUpperCase()}
            </Text>
          </View>
          <View style={styles.statusContainer}>
            <Text
              style={[
                styles.status,
                { color: getStatusColor(registro.status) },
              ]}>
              {registro.status.toUpperCase()}
            </Text>
          </View>
        </View>
      ))}
    </View>
  );

  if (loading) {
    return (
      <View style={[styles.container, styles.centered]}>
        <ActivityIndicator size="large" color="#007bff" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => mudarMes(-1)}>
          <Ionicons name="chevron-back" size={24} color="#007bff" />
        </TouchableOpacity>
        <Text style={styles.titulo}>
          {filtroMes.toLocaleDateString('pt-BR', {
            month: 'long',
            year: 'numeric',
          })}
        </Text>
        <TouchableOpacity onPress={() => mudarMes(1)}>
          <Ionicons name="chevron-forward" size={24} color="#007bff" />
        </TouchableOpacity>
      </View>

      <FlatList
        data={registros}
        keyExtractor={(item) => item.data}
        renderItem={renderItem}
        ListEmptyComponent={
          <Text style={styles.semRegistros}>
            Nenhum registro encontrado para este mês.
          </Text>
        }
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  centered: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
    backgroundColor: '#f8f9fa',
  },
  titulo: {
    fontSize: 18,
    fontWeight: 'bold',
    textTransform: 'capitalize',
  },
  diaContainer: {
    marginBottom: 16,
    padding: 16,
    backgroundColor: '#fff',
    borderRadius: 8,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  dataHeader: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 12,
    color: '#333',
  },
  registroContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  registroInfo: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
  },
  hora: {
    fontSize: 16,
    fontWeight: '500',
    marginRight: 16,
    color: '#333',
  },
  tipo: {
    fontSize: 14,
    fontWeight: 'bold',
  },
  statusContainer: {
    marginLeft: 16,
  },
  status: {
    fontSize: 12,
    fontWeight: 'bold',
    textTransform: 'uppercase',
  },
  semRegistros: {
    textAlign: 'center',
    marginTop: 20,
    color: '#888',
    fontSize: 16,
  },
});

export default TelaHistorico;
