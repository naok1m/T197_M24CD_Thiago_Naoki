import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

// Importação das telas
import TelaCadastro from './TelaCadastro'
import TelaLogin from './TelaLogin'
import TelaRecupSenha from './TelaRecupSenha'
import TelaRegistroPonto from './TelaRegistroPonto'
import TelaConfig from './TelaConfig'
import TelaHistorico from './TelaHistorico';
import TelaPerfil from './TelaPerfil';
import TelaNotificacoes from './TelaNotificacoes'
import { ThemeProvider } from './ThemeContext';
import { AuthProvider } from './AuthContext';


// Criação do Stack Navigator
const Stack = createStackNavigator();

// Componente de navegação que usa o contexto de autenticação
function Navigation() {
  return (
    <Stack.Navigator initialRouteName="TelaLogin">
      <Stack.Screen name="TelaLogin" component={TelaLogin} />
      <Stack.Screen name="RecupSenha" component={TelaRecupSenha} />
      <Stack.Screen name="TelaCadastro" component={TelaCadastro} />
      <Stack.Screen name="TelaRegPonto" component={TelaRegistroPonto} />
      <Stack.Screen name="TelaConfig" component={TelaConfig} />
      <Stack.Screen name="TelaPerfil" component={TelaPerfil} />
      <Stack.Screen name="TelaHistorico" component={TelaHistorico} />
      <Stack.Screen name="TelaNotificacoes" component={TelaNotificacoes} />
    </Stack.Navigator>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <ThemeProvider>
        <NavigationContainer>
          <Navigation />
        </NavigationContainer>
      </ThemeProvider>
    </AuthProvider>
  );
}
